const Post = require('../models/post');
const slugify = require('slugify');
const shortid = require('shortid');
const Category = require('../models/category');

exports.createCategory = (req,res) => {
  const {
    name, 
  }
}